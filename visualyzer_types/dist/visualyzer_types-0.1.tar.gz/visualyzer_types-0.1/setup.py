# visualyzer_types/setup.py

from setuptools import setup, find_packages

setup(
    name='visualyzer_types',
    version='0.1',
    description='Visualizer types',
    author='Professor',
    author_email='gulzira@bu.edu',
    packages=find_packages(),
    install_requires=[
        'matplotlib',
    ],
)
